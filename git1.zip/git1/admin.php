<?php
SESSION_START();
?>
<html>
<head>
<style>
</style></head>
<body>
<form action="#" method="POST">
<center><fieldset style="width:280px;height:220px;border-radius:13px;">
<legend>login/sign up</legend>
<div class="inputs">
                 <table> <label for="email">username</label><br>
                  <input type="text" name="username" style="border-radius:12px;width:200px;height:25px"><br>
                  <label for="password">Password</label><br>
                  <input type="number" name="password" style="border-radius:12px; width:200px;height:25px;"><br></table></div>
				  <input type="submit" value="login">
				  </center></fieldset>
				  </div>
				  </body>
				  </form>
				  </html>
<?php
if(count($_POST)>0){
$con=mysqli_connect("localhost","root","","lyceee");
$a=$_POST['username'];
$b=$_POST['password'];
if($con){
$sql=mysqli_query($con,"select* from administrator where username='$a' and password='$b'");
$row=mysqli_fetch_array($sql);
if(is_array($row)){
$_SESSION['ADid']=$row['ADid'];
$_SESSION['username']=$row['username'];
$_SESSION['password']=$row['password'];
}
if(isset($_SESSION['password'])){
header("location:parentcomments.php");
}
else {
echo"access denied";
}
}
}
?>