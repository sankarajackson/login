<?php 
SESSION_START();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--==== ICONS PACK  ======-->
    <link rel="stylesheet" href="./vendor/boxicons-2.0.7/css/boxicons.min.css">
    <!--==== MAIN CSS STYLES====-->
    <link rel="stylesheet" href="./assets/css/styles.css">
	<!--==== CONTACT US CSS STYLES====-->
    <link rel="stylesheet" href="contactus.css">
    <title>LDM | Home</title>
</head>
<body> 
    <!--==== HEADER ========-->
    <header class="header">
        <a href="#" class="header__logo">Lycee De Muhura.</a>

        <div class="header__toggle-menu">
            <i class="bx bx-menu-alt-right" id="header-toggle"></i>
        </div>

        <nav class="nav" id="nav-menu">
            <div class="nav__content bd-grid"> 
                <a href="#" class="nav__profile">
                    <div class="nav__image">
                        <img src="./assets/img/logo.jpg" alt="Logo">
                    </div>
                    <div>
                        <span class="nav__name">Lycee Saint Alexandre</span>
                        <span class="nav__name">Sauli De Muhura.</span>
                    </div>
                </a>
                <div class="nav__menu">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="index.html" class="nav__link active">Home</a></li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">About <i class="bx bx-chevron-down dropdown__icon"></i></a>

                            <ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="history.html" class="nav__link">History</a></li>
                                <li class="dropdown__item"><a href="mission.html" class="nav__link">Mission</a></li>
                                <li class="dropdown__item"><a href="vision.html" class="nav__link">Vision</a></li>
								<li class="dropdown__item"><a href="map.html" class="nav__link">find our location</a></li>
                            </ul>
                        </li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">Updates <i class="bx bx-chevron-down dropdown__icon"></i></a>
						
						<ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="Meeting.html" class="nav__link">Parent's Meeting</a></li>
                                <li class="dropdown__item"><a href="updates.html" class="nav__link">Rules and Regulation</a></li>
                                <li class="dropdown__item"><a href="computer.html" class="nav__link">Fees Structure</a></li>
                            </ul>
							</li>
                        <li class="nav__item"><a href="teachers.html" class="nav__link">Teachers</a></li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">TRADES <i class="bx bx-chevron-down dropdown__icon"></i></a>
                        
                            <ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="tailoring.html" class="nav__link">TAL</a></li>
                                <li class="dropdown__item"><a href="accountant.html" class="nav__link">ACC</a></li>
                                <li class="dropdown__item"><a href="computer.html" class="nav__link">CSC</a></li>
                            </ul>
                        </li>
                        <li class="nav__item"><a href="gallery.html" class="nav__link">Gallery</a></li>
                        <li class="nav__item"><a href="#" class="nav__link">Contact us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	<main class="main__content">
	 <section class="section">
<div class="container" style="width:88%;margin-left:6%;margin-right:6%;margin-top:-8%">
<h3 style="text-align:center;">Please!<br>Contact us for Any Concern and Ideas</h3>
  <form action="#" method="POST">
  <h3>WELCOME MRS <?php echo  $parentnames. "has been removed"?>, check out new comments</h3>
    <label for="fname">Names</label>
    <input type="text" id="names" name="pnames" placeholder="Your name.." style="border-color:rgba(228, 209, 124, 1)"required>
	
	<label for="fname">email</label>
    <input type="text" id="email" name="email" placeholder="Your name.." style="border-color:rgba(228, 209, 124, 1)"required>

    <label for="email">Telephone</label><br>
    <input type="number"  name="telephone" placeholder="Your number.." style="width:620px;height:40px;border-radius:5px;border-color:rgba(228, 209, 124, 1)"required><br>
	
<label for="email">student name</label><br>
    <input type="text"  name="sname" placeholder="Your child.." style="width:620px;height:40px;border-radius:5px;border-color:rgba(228, 209, 124, 1)"required><br>
    

    <label for="subject"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M7 7H17V9H7zM7 11H14V13H7z"/><path d="M20,2H4C2.897,2,2,2.897,2,4v18l5.333-4H20c1.103,0,2-0.897,2-2V4C22,2.897,21.103,2,20,2z M20,16H6.667L4,18V4h16V16z"/></svg>Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px;border-color:rgba(228, 209, 124, 1)"  required></textarea>

    <input type="submit" value="Submit">
  </form>
</div><br>
<div class="head">
	<fieldset>
	<img src="parade.jpg" alt="width:10%; height:3%;">
	<H2 style="text-align:center;"><u>HEAD TEACHERS</u></h2>
	<h4 style="text-align:center;">Padiri SINABAJIJE Alphonse<br>
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="18" viewBox="0 0 24 24"><path d="M20,4H6C4.897,4,4,4.897,4,6v5h2V8l6.4,4.8c0.178,0.133,0.389,0.2,0.6,0.2s0.422-0.067,0.6-0.2L20,8v9h-8v2h8 c1.103,0,2-0.897,2-2V6C22,4.897,21.103,4,20,4z M13,10.75L6.666,6h12.668L13,10.75z"/><path d="M2 12H9V14H2zM4 15H10V17H4zM7 18H11V20H7z"/></svg>Email: sinabajijeAll@gmail.com<br>
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M16.585,19.999l2.006-2.005l-2.586-2.586l-1.293,1.293c-0.238,0.239-0.579,0.342-0.912,0.271 c-0.115-0.024-2.842-0.611-4.502-2.271s-2.247-4.387-2.271-4.502c-0.069-0.33,0.032-0.674,0.271-0.912l1.293-1.293L6.005,5.408 L4,7.413c0.02,1.223,0.346,5.508,3.712,8.874C11.067,19.643,15.337,19.978,16.585,19.999z"/><path d="M16.566 21.999c.005 0 .023 0 .028 0 .528 0 1.027-.208 1.405-.586l2.712-2.712c.391-.391.391-1.023 0-1.414l-4-4c-.391-.391-1.023-.391-1.414 0l-1.594 1.594c-.739-.22-2.118-.72-2.992-1.594s-1.374-2.253-1.594-2.992l1.594-1.594c.391-.391.391-1.023 0-1.414l-4-4c-.375-.375-1.039-.375-1.414 0L2.586 5.999C2.206 6.379 1.992 6.901 2 7.434c.023 1.424.4 6.37 4.298 10.268S15.142 21.976 16.566 21.999zM6.005 5.408l2.586 2.586L7.298 9.287c-.239.238-.341.582-.271.912.024.115.611 2.842 2.271 4.502s4.387 2.247 4.502 2.271c.333.07.674-.032.912-.271l1.293-1.293 2.586 2.586-2.006 2.005c-1.248-.021-5.518-.356-8.873-3.712C4.346 12.921 4.02 8.636 4 7.413L6.005 5.408zM19.999 10.999h2c0-5.13-3.873-8.999-9.01-8.999v2C17.051 4 19.999 6.943 19.999 10.999z"/><path d="M12.999,8c2.103,0,3,0.897,3,3h2c0-3.225-1.775-5-5-5V8z"/></svg>Tel: +250 784 566 333</h4>
   <a href="computer.html" class="btn" style="align-items:center;">Lean more</a>
   </fieldset></div>
   <!--====DOS'S SIDE===-->	
   <div class="dos">
	<fieldset>
	<img src="parade.jpg" alt="width:10%; height:3%;">
	<H2 style="text-align:center;"><u>HEAD TEACHERS</u></h2>
	<h4 style="text-align:center;">Padiri SINABAJIJE Alphonse<br>
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="18" viewBox="0 0 24 24"><path d="M20,4H6C4.897,4,4,4.897,4,6v5h2V8l6.4,4.8c0.178,0.133,0.389,0.2,0.6,0.2s0.422-0.067,0.6-0.2L20,8v9h-8v2h8 c1.103,0,2-0.897,2-2V6C22,4.897,21.103,4,20,4z M13,10.75L6.666,6h12.668L13,10.75z"/><path d="M2 12H9V14H2zM4 15H10V17H4zM7 18H11V20H7z"/></svg>Email: sinabajijeAll@gmail.com<br>
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M16.585,19.999l2.006-2.005l-2.586-2.586l-1.293,1.293c-0.238,0.239-0.579,0.342-0.912,0.271 c-0.115-0.024-2.842-0.611-4.502-2.271s-2.247-4.387-2.271-4.502c-0.069-0.33,0.032-0.674,0.271-0.912l1.293-1.293L6.005,5.408 L4,7.413c0.02,1.223,0.346,5.508,3.712,8.874C11.067,19.643,15.337,19.978,16.585,19.999z"/><path d="M16.566 21.999c.005 0 .023 0 .028 0 .528 0 1.027-.208 1.405-.586l2.712-2.712c.391-.391.391-1.023 0-1.414l-4-4c-.391-.391-1.023-.391-1.414 0l-1.594 1.594c-.739-.22-2.118-.72-2.992-1.594s-1.374-2.253-1.594-2.992l1.594-1.594c.391-.391.391-1.023 0-1.414l-4-4c-.375-.375-1.039-.375-1.414 0L2.586 5.999C2.206 6.379 1.992 6.901 2 7.434c.023 1.424.4 6.37 4.298 10.268S15.142 21.976 16.566 21.999zM6.005 5.408l2.586 2.586L7.298 9.287c-.239.238-.341.582-.271.912.024.115.611 2.842 2.271 4.502s4.387 2.247 4.502 2.271c.333.07.674-.032.912-.271l1.293-1.293 2.586 2.586-2.006 2.005c-1.248-.021-5.518-.356-8.873-3.712C4.346 12.921 4.02 8.636 4 7.413L6.005 5.408zM19.999 10.999h2c0-5.13-3.873-8.999-9.01-8.999v2C17.051 4 19.999 6.943 19.999 10.999z"/><path d="M12.999,8c2.103,0,3,0.897,3,3h2c0-3.225-1.775-5-5-5V8z"/></svg>Tel: +250 784 566 333</h4>
   <a href="computer.html" class="btn" style="align-items:center;">Lean more</a>
   </fieldset></div>
   <!--====bas'S SIDE===-->	
   <div class="bas">
	<fieldset>
	<img src="parade.jpg" alt="width:10%; height:3%;">
	<H2 style="text-align:center;"><u>HEAD TEACHERS</u></h2>
	<h4 style="text-align:center;">Padiri SINABAJIJE Alphonse<br>
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="18" viewBox="0 0 24 24"><path d="M20,4H6C4.897,4,4,4.897,4,6v5h2V8l6.4,4.8c0.178,0.133,0.389,0.2,0.6,0.2s0.422-0.067,0.6-0.2L20,8v9h-8v2h8 c1.103,0,2-0.897,2-2V6C22,4.897,21.103,4,20,4z M13,10.75L6.666,6h12.668L13,10.75z"/><path d="M2 12H9V14H2zM4 15H10V17H4zM7 18H11V20H7z"/></svg>Email: sinabajijeAll@gmail.com<br>
	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M16.585,19.999l2.006-2.005l-2.586-2.586l-1.293,1.293c-0.238,0.239-0.579,0.342-0.912,0.271 c-0.115-0.024-2.842-0.611-4.502-2.271s-2.247-4.387-2.271-4.502c-0.069-0.33,0.032-0.674,0.271-0.912l1.293-1.293L6.005,5.408 L4,7.413c0.02,1.223,0.346,5.508,3.712,8.874C11.067,19.643,15.337,19.978,16.585,19.999z"/><path d="M16.566 21.999c.005 0 .023 0 .028 0 .528 0 1.027-.208 1.405-.586l2.712-2.712c.391-.391.391-1.023 0-1.414l-4-4c-.391-.391-1.023-.391-1.414 0l-1.594 1.594c-.739-.22-2.118-.72-2.992-1.594s-1.374-2.253-1.594-2.992l1.594-1.594c.391-.391.391-1.023 0-1.414l-4-4c-.375-.375-1.039-.375-1.414 0L2.586 5.999C2.206 6.379 1.992 6.901 2 7.434c.023 1.424.4 6.37 4.298 10.268S15.142 21.976 16.566 21.999zM6.005 5.408l2.586 2.586L7.298 9.287c-.239.238-.341.582-.271.912.024.115.611 2.842 2.271 4.502s4.387 2.247 4.502 2.271c.333.07.674-.032.912-.271l1.293-1.293 2.586 2.586-2.006 2.005c-1.248-.021-5.518-.356-8.873-3.712C4.346 12.921 4.02 8.636 4 7.413L6.005 5.408zM19.999 10.999h2c0-5.13-3.873-8.999-9.01-8.999v2C17.051 4 19.999 6.943 19.999 10.999z"/><path d="M12.999,8c2.103,0,3,0.897,3,3h2c0-3.225-1.775-5-5-5V8z"/></svg>Tel: +250 784 566 333</h4>
   <a href="computer.html" class="btn" style="align-items:center;">Lean more</a>
   </fieldset></div>
	</main>
	 <!--===== FOOTER ======-->
    <footer class="footer section">
        <div class="footer__container bd-container bd-grid">
            <div class="footer__content"> 
                <h3 class="footer__title">
                    <a href="#" class="footer__logo">Lycee De Muhura</a>
                </h3>
                <p class="footer__description">Knowledge, Light and <br> Discpline</p>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">About us</h3>
                <ul>
                    <li><a href="history.html" class="footer__link">History </a></li>
                    <li><a href="mission.html" class="footer__link">Mission</a></li>
                    <li><a href="vision.html" class="footer__link">Vision</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">Programs</h3>
                <ul>
                
                   <li><a href="tailoring.html" class="footer__link">TAL</a></li>
                    <li><a href="accountant.html" class="footer__link">ACC</a></li>
                    <li><a href="computer.html" class="footer__link">CSC</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">Our social media</h3>
                <a href="https://www.facebook.com/pages/category/Society---Culture-Website/Lyce%C3%A9-Saint-Alexandre-Sauli-de-Muhura-244407252588721/" class="footer__social"><i class='bx bxl-facebook-circle '></i></a>
                <a href="https://www.twitter.com/lycee_de_muhura" class="footer__social"><i class='bx bxl-twitter'></i></a>
                <a href="https://www.instagram.com/rwanda_actor_actresses_models/" class="footer__social"><i class='bx bxl-instagram-alt'></i></a>
            </div>
        </div>
        <p class="footer__copy">&#169; 2021. All right reserved by SANKARA</p>
    </footer>
    <!--===== MAIN JS ====-->
	<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
	<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
    <script src="./assets/js/scripts.js" difer></script>
</body>
</html>
<?php
if(count($_POST)>0){
$con=mysqli_connect("localhost","root","","lyceee");
$pname=$_POST['pnames'];
$email=$_POST['email'];
$phone=$_POST['telephone'];
$sname=$_POST['sname'];
$comment=$_POST['subject'];
if($con){
$insert=mysqli_query($con,"insert into parents values('','$pname','$email','$phone','$sname','$comment')");
}
if($insert){
$retrieve=mysqli_query($con,"select* from parents where parentnames='pname' and telephone='$phone'");
}
$row=mysqli_fetch_array($retrieve);
if(is_array($row)){
$_SESSION['parentnames']=$row['parentnames'];
$_SESSION['pid']=$row['pid'];
}
if(isset($_SESSION["parentnames"])){
header("location:index2.php");
}
else
echo"failed to insert";
}
?>