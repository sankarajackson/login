<?php
SESSION_START();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--==== ICONS PACK  ======-->
    <link rel="stylesheet" href="./vendor/boxicons-2.0.7/css/boxicons.min.css">
    <!--==== MAIN CSS STYLES====-->
    <link rel="stylesheet" href="./assets/css/styles.css">
    <title>LDM | Home</title>
</head>
<body> 
    <!--==== HEADER ========-->
    <header class="header">
        <a href="#" class="header__logo">Lycee De Muhura.</a>

        <div class="header__toggle-menu">
            <i class="bx bx-menu-alt-right" id="header-toggle"></i>
        </div>

        <nav class="nav" id="nav-menu">
            <div class="nav__content bd-grid"> 
                <a href="#" class="nav__profile">
                    <div class="nav__image">
                        <img src="./assets/img/logo.jpg" alt="Logo">
                    </div>
                    <div>
                        <span class="nav__name">Lycee Saint Alexandre</span>
                        <span class="nav__name">Sauli De Muhura.</span>
                    </div>
                </a>
                <div class="nav__menu">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="AD_index.html" class="nav__link active">Home</a></li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">About us <i class="bx bx-chevron-down dropdown__icon"></i></a>

                            <ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="AD_history.html" class="nav__link">History</a></li>
                                <li class="dropdown__item"><a href="AD_mission.html" class="nav__link">Mission</a></li>
                                <li class="dropdown__item"><a href="AD_vision.html" class="nav__link">Vision</a></li>
								<li class="dropdown__item"><a href="AD_map.html" class="nav__link">Map</a></li>
                            </ul>
                        </li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">NEWS <i class="bx bx-chevron-down dropdown__icon"></i></a>
						
						<ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="AD_MEETING.html" class="nav__link">Meeting</a></li>
                                <li class="dropdown__item"><a href="AD_updates.html" class="nav__link">Rules and Regulation</a></li>
                                <li class="dropdown__item"><a href="AD_computer.html" class="nav__link">Fees Structure</a></li>
                            </ul>
							</li>
                        <li class="nav__item"><a href="AD_teachers.html" class="nav__link">Collegues</a></li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">SECTORS <i class="bx bx-chevron-down dropdown__icon"></i></a>
                        
                            <ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="AD_tailoring.html" class="nav__link">Tail</a></li>
                                <li class="dropdown__item"><a href="AD_accountant.html" class="nav__link">Finnc</a></li>
                                <li class="dropdown__item"><a href="AD_computer.html" class="nav__link">Ict</a></li>
                            </ul>
                        </li>
                        <li class="nav__item"><a href="AD_gallery.html" class="nav__link">Images</a></li>
                        <li class="nav__item"><a href="AD_DELETE.php" class="nav__link">DELETE COMMENT</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	<body style="margin-top:12%;">
<center>
<form action="#" method="POST">
<h3>WELCOME MRS <?php echo  $_SESSION['username'];?>, check out new comments</h3>
<label for="password">search new updates</label><br>
 <input type="number" name="pid" style="border-radius:12px; width:200px;height:25px;" placeholder="Enter Parent Id..." required>
 <input type="submit" value="search">
</form>
</center>
<?php
if(count ($_POST)>0){
$con=mysqli_connect("localhost","root","","lyceee");
$a=$_POST['pid'];
$sql=mysqli_query($con,"select* from parents where pid='$a'");
if($sql==true){
echo"<table border='2'><tr><th>pid</th><th>parentnames</th><th>email</th><th>telephone</th><th>studentname</th><th>comment</th></tr>";
}
while($test=mysqli_fetch_array($sql)){
echo"<tr><td>{$test['pid']}</td><td>{$test['parentnames']}</td><td>{$test['email']}</td><td>{$test['telephone']}</td><td>{$test['n.student']}</td><td>{$test['comment']}</td></tr>";
}
echo"</table>";
}
?>
	</main>
    <!--===== FOOTER ======-->
    <footer class="footer section">
        <div class="footer__container bd-container bd-grid">
            <div class="footer__content"> 
                <h3 class="footer__title">
                    <a href="#" class="footer__logo">Lycee De Muhura</a>
                </h3>
                <p class="footer__description">Knowledge, Light and <br> Discpline</p>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">About us</h3>
                <ul>
                    <li><a href="history.html" class="footer__link">History </a></li>
                    <li><a href="mission.html" class="footer__link">Mission</a></li>
                    <li><a href="vision.html" class="footer__link">Vision</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">Programs</h3>
                <ul>
                    <li><a href="tailoring.html" class="footer__link">TAL</a></li>
                    <li><a href="accountant.html" class="footer__link">ACC</a></li>
                    <li><a href="computer.html" class="footer__link">CSC</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">Our social media</h3>
                <a href="https://www.facebook.com/pages/category/Society---Culture-Website/Lyce%C3%A9-Saint-Alexandre-Sauli-de-Muhura-244407252588721/" class="footer__social"><i class='bx bxl-facebook-circle '></i></a>
                <a href="https://www.twitter.com/lycee_de_muhura" class="footer__social"><i class='bx bxl-twitter'></i></a>
                <a href="https://www.instagram.com/rwanda_actor_actresses_models/" class="footer__social"><i class='bx bxl-instagram-alt'></i></a>
            </div>
        </div>
        <p class="footer__copy">&#169; 2021. All right reserved by SANKARA Jackson</p>
    </footer>
    <!--===== MAIN JS ====-->
	<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
	<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
    <script src="./assets/js/scripts.js" difer></script>
</body>
</html>