<?php
SESSION_START();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--==== ICONS PACK  ======-->
    <link rel="stylesheet" href="./vendor/boxicons-2.0.7/css/boxicons.min.css">
    <!--==== MAIN CSS STYLES====-->
    <link rel="stylesheet" href="./assets/css/styles.css">
    <title>LDM | Home</title>
</head>
<body> 
    <!--==== HEADER ========-->
    <header class="header">
        <a href="#" class="header__logo">Lycee De Muhura.</a>

        <div class="header__toggle-menu">
            <i class="bx bx-menu-alt-right" id="header-toggle"></i>
        </div>

        <nav class="nav" id="nav-menu">
            <div class="nav__content bd-grid"> 
                <a href="#" class="nav__profile">
                    <div class="nav__image">
                        <img src="./assets/img/logo.jpg" alt="Logo">
                    </div>
                    <div>
                        <span class="nav__name">Lycee Saint Alexandre</span>
                        <span class="nav__name">Sauli De Muhura.</span>
                    </div>
                </a>
                <div class="nav__menu">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="index.html" class="nav__link active"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3,13h1v2v5c0,1.103,0.897,2,2,2h3h6h3c1.103,0,2-0.897,2-2v-5v-2h1c0.404,
						0,0.77-0.244,0.924-0.617 c0.155-0.374,0.069-0.804-0.217-1.09l-9-9c-0.391-0.391-1.023-0.391-1.414,0l-9,9c-0.286,0.286-0.372,0.716-0.217,1.09 C2.23,12.756,2.596,
						13,3,13z M10,20v-5h4v5H10z M12,4.414l6,6V15l0,0l0.001,5H16v-5c0-1.103-0.897-2-2-2h-4c-1.103,0-2,0.897-2,2v5 H6v-5v-3v-1.586L12,4.414z"/></svg>Home</a></li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">About <i class="bx bx-chevron-down dropdown__icon"></i></a>

                            <ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="history.html" class="nav__link">History</a></li>
                                <li class="dropdown__item"><a href="mission.html" class="nav__link">Mission</a></li>
                                <li class="dropdown__item"><a href="vision.html" class="nav__link">Vision</a></li>
								<li class="dropdown__item"><a href="map.html" class="nav__link">find our location</a></li>
                            </ul>
                        </li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">Updates <i class="bx bx-chevron-down dropdown__icon"></i></a>
						
						<ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="Meeting.html" class="nav__link">Parent's Meeting</a></li>
                                <li class="dropdown__item"><a href="updates.html" class="nav__link">Rules and Regulation</a></li>
                                <li class="dropdown__item"><a href="computer.html" class="nav__link">Fees Structure</a></li>
                            </ul>
							</li>
                        <li class="nav__item"><a href="teachers.html" class="nav__link">Teachers</a></li>
                        <li class="nav__item dropdown">
                            <a href="#" class="nav__link dropdown__link">TRADES <i class="bx bx-chevron-down dropdown__icon"></i></a>
                        
                            <ul class="dropdown__menu">
                                <li class="dropdown__item"><a href="tailoring.html" class="nav__link">TAL</a></li>
                                <li class="dropdown__item"><a href="accountant.html" class="nav__link">ACC</a></li>
                                <li class="dropdown__item"><a href="computer.html" class="nav__link">CSC</a></li>
                            </ul>
                        </li>
                        <li class="nav__item"><a href="gallery.html" class="nav__link">Gallery</a></li>
                        <li class="nav__item"><a href="contactus.php" class="nav__link">Contact us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main class="main__content">
        <!--====== HOME =====-->
		 <div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  HELLO, <?php echo $_SESSION['parentnames'];?> <strong>THANKS FOR YOUR SUPPORT!</strong>
</div>
        <section class="slideshow__container">
            <div class="my__slides fade">
                <img src="./assets/img/ground.jpg" alt="width:100%; height:1%;">
                <div class="caption">
                    <p class="text">WELCOME TO LYCEE DE MUHURA <br>One of the oldest,<br> 
					yet the best performing Government High School in Rwanda. <br>
					<br>We strive to produce students with the<br>
					perfect balance of both academics and societal values.</p>
                    <a href="computer.html" class="btn">Lean more</a>
                </div>
            </div>
            <div class="my__slides">
                <img src="Accountant.jpg" alt="width:100%; height:2%;">
                <div class="caption">
                    <p class="text"> Accounting... <br>Something related to image</p>
                    <a href="accountant.html" class="btn">Lean more</a>
                </div>
            </div>
            <div class="my__slides fade">
                <img src="./assets/img/tailoring.jpg" alt="width:100%; height:2%;">
                <div class="caption">
                    <p class="text">Tailoring .... <br>Something related to image</p>
                    <a href="tailoring.html" class="btn">Lean more</a>
                </div>
            </div>
            <div class="my__slides fade">
                <img src="./assets/img/itorero2.jpg" alt="width:100%; height:2%;">
                <div class="caption">
                    <p class="text">School activities..... <br> Something related to image</p>
                    <a href="gallery.html" class="btn">Lean more</a>
                </div>
            </div>
            <!--USE IF DONT WANT AUTOSLIDE  -->
            <!-- <a class="prev" onclick="plusSlides(-1)"><i class='bx bxs-chevron-left-circle'></i></a>
            <a class="next" onclick="plusSlides(1)"><i class='bx bxs-chevron-right-circle'></i></a> -->
        </section>
        <!--USE IF DONT WANT AUTOSLIDE  -->
        <!-- <section style="text-align:center">
            <span class="indicator" onclick="currentSlide(1)"></span>
            <span class="indicator" onclick="currentSlide(2)"></span>
            <span class="indicator" onclick="currentSlide(3)"></span>
            <span class="indicator" onclick="currentSlide(4)"></span>
        </section> -->


        <!--===== SOME CONTENT HERE =====-->
        <section class="section">

        </section>
<div class="news">
<fieldset>
<img src="leader.jpg" alt="width:15%; height:5%;">

    Post-Genocide, LYCEE DE MUHURA underwent major 
	changes and reforms, all aimed at making it a better 
	institution and today these efforts have paid off.<br>
	LYCEE DE MUHURA is one of the best schools in Rwanda,
	feeding into major universities in Rwanda.
	<a href="leader.html" class="btn" style="align-items:center;">Lean more</a>
	</fieldset>
    </div>
	<div class="updates">
	<fieldset>
	<img src="parade.jpg" alt="width:15%; height:5%;">
of many in terms of consistency in excellent performance.
    Lycee De Muhura started in 1992 by the French as a 
	science-modelled high school. Indeed,<br> 
    it has transcended leaps and bounds to become one 
	of the best mixed high schools in Rwanda.

   Since the Government took charge of the school in 1982,
   there has been enormous progress in all aspects.
   <a href="computer.html" class="btn" style="align-items:center;">Lean more</a>
   </fieldset>
    </div>
	</main>
    <!--===== FOOTER ======-->
    <footer class="footer section">
        <div class="footer__container bd-container bd-grid">
            <div class="footer__content"> 
                <h3 class="footer__title">
                    <a href="#" class="footer__logo">Lycee De Muhura</a>
                </h3>
                <p class="footer__description">Knowledge, Light and <br> Discpline</p>
			
            </div>
            <div class="footer__content">
                <h3 class="footer__title">About us</h3>
                <ul>
                    <li><a href="history.html" class="footer__link">History </a></li>
                    <li><a href="mission.html" class="footer__link">Mission</a></li>
                    <li><a href="vision.html" class="footer__link">Vision</a></li>
					<li style="display:block;border-radius:5px;background-color:tomato;width:28%;text-align:center"><a href="login.php" class="footer__link">LOGIN</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">Programs</h3>
                <ul>
                    <li><a href="tailoring.html" class="footer__link">TAL</a></li>
                    <li><a href="accountant.html" class="footer__link">ACC</a></li>
                    <li><a href="computer.html" class="footer__link">CSC</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">Our social media</h3>
                <a href="https://www.facebook.com/pages/category/Society---Culture-Website/Lyce%C3%A9-Saint-Alexandre-Sauli-de-Muhura-244407252588721/" class="footer__social"><i class='bx bxl-facebook-circle '></i></a>
                <a href="https://www.twitter.com/lycee_de_muhura" class="footer__social"><i class='bx bxl-twitter'></i></a>
                <a href="https://www.instagram.com/rwanda_actor_actresses_models/" class="footer__social"><i class='bx bxl-instagram-alt'></i></a>
            </div>
        </div>
        <p class="footer__copy">&#169; 2021. All right reserved by SANKARA Jackson</p>
    </footer>
    <!--===== MAIN JS ====-->
	<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
	<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
    <script src="./assets/js/scripts.js" difer></script>
</body>
</html>