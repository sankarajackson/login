<?php
SESSION_START();
?>
<?php
unset($_SESSION['username']);
unset($_SESSION['password']);
header("location:htdocs/index.html");
?>